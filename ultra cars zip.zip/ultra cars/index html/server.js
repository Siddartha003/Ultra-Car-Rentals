const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs'); // <-- Add this at the top

const app = express();
const PORT = 5500;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// POST route for form submission — modified to save to file
app.post('/search', (req, res) => {
  const { pickup, dropoff, startDate, endDate } = req.body;

  const entry = `${new Date().toISOString()} - ${pickup} to ${dropoff}, ${startDate} to ${endDate}\n`;

  fs.appendFile('searches.txt', entry, err => {
    if (err) {
      console.error('Error saving search:', err);
      return res.status(500).send('Server error while saving search');
    }

    console.log('Search submitted and saved:', { pickup, dropoff, startDate, endDate });

    res.send(`<h1>Search Received</h1><p>${pickup} to ${dropoff} from ${startDate} to ${endDate}</p>`);
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
