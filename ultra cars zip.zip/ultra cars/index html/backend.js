// app.js

const carList = ["Tesla Model 3", "BMW 5 Series", "Audi A4"];

// Render the list of cars
function renderCars() {
  const container = document.getElementById("car-list");
  carList.forEach(car => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <h3>${car}</h3>
      <p>$99/day</p>
      <button>Rent Now</button>
    `;
    container.appendChild(card);
  });
}

// Handle search form submission without page reload
document.addEventListener('DOMContentLoaded', () => {
  renderCars(); // render cars when page loads

  const searchForm = document.getElementById('searchForm');
  if (searchForm) {
    searchForm.addEventListener('submit', async function (e) {
      e.preventDefault(); // prevent default form behavior

      const formData = new FormData(this);

      const response = await fetch('/search', {
        method: 'POST',
        body: new URLSearchParams(formData),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      const resultHTML = await response.text();
      document.getElementById('searchResult').innerHTML = resultHTML;
    });
  }
});
